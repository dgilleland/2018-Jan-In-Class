﻿
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

partial class FormSamples_JobApplication
    : System.Web.UI.Page
{
    protected void Page_Load(Object sender, EventArgs e)
    {
    }
}
